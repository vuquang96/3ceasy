<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Shop Tabs', 'wplab-recover' ),
		'description' => esc_html__( 'New / Featured / Popular / Top Rated', 'wplab-recover' ),
		'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
	)
);