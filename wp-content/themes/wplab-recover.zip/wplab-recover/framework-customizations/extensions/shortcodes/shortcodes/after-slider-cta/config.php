<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'After Slider CTA', 'wplab-recover' ),
		'description' => esc_html__( 'Add number of projects and CTA after slider', 'wplab-recover' ),
		'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
	)
);