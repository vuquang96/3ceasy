<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Video', 'wplab-recover'),
	'description'   => esc_html__('Add a Video', 'wplab-recover'),
	'tab'           => esc_html__('Media Elements', 'wplab-recover'),
);
