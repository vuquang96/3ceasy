<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Logos', 'wplab-recover' ),
		'description' => esc_html__( 'Add Logos Grid', 'wplab-recover' ),
		'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
	)
);