<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'List', 'wplab-recover' ),
		'description' => esc_html__( 'Add a list', 'wplab-recover' ),
		'tab'         => esc_html__( 'Content Elements', 'wplab-recover' ),
	)
);