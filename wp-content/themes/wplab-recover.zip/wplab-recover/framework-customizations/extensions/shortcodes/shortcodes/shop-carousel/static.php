<?php if (!defined('FW')) die('Forbidden');

global $wplab_recover_core;

wp_enqueue_style( 'shop-carousel-shortcode', $wplab_recover_core->skin_style_dir . '/shop-carousel.css', false, _WPLAB_RECOVER_CACHE_TIME_ );