<?php if (!defined('FW')) die('Forbidden');

global $wplab_recover_core;

wp_enqueue_style( 'partners_clients', $wplab_recover_core->skin_style_dir . '/partners_clients.css', false, _WPLAB_RECOVER_CACHE_TIME_ );