<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Portfolio Projects', 'wplab-recover' ),
		'description' => esc_html__( 'Classic portfolio with filters', 'wplab-recover' ),
		'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
	)
);