<?php if (!defined('FW')) die('Forbidden');

global $wplab_recover_core;

wp_enqueue_style( 'after-slider-cta', $wplab_recover_core->skin_style_dir . '/after_slider_cta.css', false, _WPLAB_RECOVER_CACHE_TIME_ );