<?php
	global $wplab_recover_core;
	wp_enqueue_style( 'theme-slider', $wplab_recover_core->skin_style_dir . '/slider.css', false, _WPLAB_RECOVER_CACHE_TIME_ );