<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => esc_html__('Image', 'wplab-recover'),
	'description'   => esc_html__('Add an Image', 'wplab-recover'),
	'tab'           => esc_html__('Media Elements', 'wplab-recover'),
);