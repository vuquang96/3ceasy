<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Contact Info', 'wplab-recover' ),
	'description' => esc_html__( 'Add contact information', 'wplab-recover' ),
	'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
);