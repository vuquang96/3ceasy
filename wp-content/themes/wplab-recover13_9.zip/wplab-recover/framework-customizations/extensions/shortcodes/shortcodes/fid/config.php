<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Facts In Digits', 'wplab-recover' ),
		'description' => esc_html__( 'Add Facts In Digits element', 'wplab-recover' ),
		'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
	)
);