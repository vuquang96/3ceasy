<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Benefits', 'wplab-recover' ),
	'description' => esc_html__( 'Benefits Section', 'wplab-recover' ),
	'tab'         => esc_html__( 'Theme Elements', 'wplab-recover' ),
);