<?php if (!defined('FW')) die('Forbidden'); ?>

<div class="fw-row">
	<?php echo do_shortcode($content); ?>
</div>

