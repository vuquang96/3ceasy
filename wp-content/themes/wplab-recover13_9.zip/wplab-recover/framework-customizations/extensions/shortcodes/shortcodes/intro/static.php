<?php 
	global $wplab_recover_core;
	wp_enqueue_style( 'theme-intro-shortcode', $wplab_recover_core->skin_style_dir . '/intro.css', false, _WPLAB_RECOVER_CACHE_TIME_ );